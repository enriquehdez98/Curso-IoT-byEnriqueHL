#include <Arduino.h>
#define LED_BUILTIN 2


void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  pinMode(LED_BUILTIN, OUTPUT);
  Serial.println("Hello, World!");
}

void loop() {
  // put your main code here, to run repeatedly:
  Serial.println("LED is ON");
  digitalWrite(LED_BUILTIN, HIGH);   // turn the LED on (HIGH is the voltage level)
  delay(1000);    
  Serial.println("LED is OFF");                   // wait for a second  
  digitalWrite(LED_BUILTIN, LOW);    // turn the LED off (LOW is the voltage level)
  delay(1000);
}

